
List of Evidences

1. Sn1: Solution 1

   examples_example_gsn_yaml

   https://github.com/jonasthewolf/gsn2x

2. Sn2: Solution 2

   examples_example_gsn_yaml

   LAYER1: Additional information on layer 1

3. Sn3: Solution 3

   examples_example_gsn_yaml

4. Sn4: Solution 4

   examples_example_gsn_yaml

5. Sn5: Solution 5

   examples_example_gsn_yaml

