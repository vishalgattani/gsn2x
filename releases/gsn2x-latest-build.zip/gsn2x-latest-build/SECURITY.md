
This software assumes only trusted input.
Thus, no security issues are expected.

If there is an issue anyway, feel free to contact me and I will try to fix it.